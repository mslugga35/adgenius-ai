
export interface AdFormat {
  id: string;
  name: string;
  prompt: string;
}
